#include "library.h"
#include "util.h"
int main()
{
int* timeviewed=new int;
int* classes;
int* courses;
ofstream myfile;
myfile.open("myoutput.txt");
//Line Number: 0
void *DS1=Init();
//Line Number: 1
ASSERT_TEST(AddCourse(DS1,2,2)==SUCCESS);
//Line Number: 2
ASSERT_TEST(RemoveCourse(DS1,-1)==INVALID_INPUT);
//Line Number: 3
ASSERT_TEST(AddCourse(DS1,5,5)==SUCCESS);
//Line Number: 4
ASSERT_TEST(AddCourse(DS1,10,10)==SUCCESS);
//Line Number: 5
ASSERT_TEST(AddCourse(DS1,9,9)==SUCCESS);
//Line Number: 6
ASSERT_TEST(AddCourse(DS1,13,13)==SUCCESS);
//Line Number: 7
ASSERT_TEST(RemoveCourse(DS1,16)==FAILURE);
//Line Number: 8
ASSERT_TEST(RemoveCourse(DS1,17)==FAILURE);
//Line Number: 9
ASSERT_TEST(AddCourse(DS1,10,10)==FAILURE);
//Line Number: 10
ASSERT_TEST(RemoveCourse(DS1,14)==FAILURE);
//Line Number: 11
ASSERT_TEST(RemoveCourse(DS1,3)==FAILURE);
//Line Number: 12
ASSERT_TEST(AddCourse(DS1,6,6)==SUCCESS);
//Line Number: 13
ASSERT_TEST(AddCourse(DS1,1,1)==SUCCESS);
//Line Number: 14
ASSERT_TEST(RemoveCourse(DS1,-12)==INVALID_INPUT);
//Line Number: 15
ASSERT_TEST(AddCourse(DS1,2,2)==FAILURE);
//Line Number: 16
ASSERT_TEST(AddCourse(DS1,3,3)==SUCCESS);
//Line Number: 17
ASSERT_TEST(AddCourse(DS1,20,20)==SUCCESS);
//Line Number: 18
ASSERT_TEST(AddCourse(DS1,13,13)==FAILURE);
//Line Number: 19
ASSERT_TEST(AddCourse(DS1,1,1)==FAILURE);
//Line Number: 20
ASSERT_TEST(AddCourse(DS1,8,8)==SUCCESS);
//Line Number: 21
ASSERT_TEST(AddCourse(DS1,7,7)==SUCCESS);
//Line Number: 22
ASSERT_TEST(AddCourse(DS1,13,13)==FAILURE);
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF ADD REMOVE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
//Line Number: 23
void *DS2=Init();
//Line Number: 24
ASSERT_TEST(AddCourse(DS2,9,7)==SUCCESS);
//Line Number: 25
ASSERT_TEST(WatchClass(DS2,9,2,2)==SUCCESS);
//Line Number: 26
ASSERT_TEST(TimeViewed(DS2,9,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==2);
//Line Number: 27
ASSERT_TEST(WatchClass(DS2,9,2,2)==SUCCESS);
//Line Number: 28
ASSERT_TEST(TimeViewed(DS2,9,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==4);
//Line Number: 29
ASSERT_TEST(WatchClass(DS2,9,1,2)==SUCCESS);
//Line Number: 30
ASSERT_TEST(TimeViewed(DS2,9,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==2);
//Line Number: 31
ASSERT_TEST(WatchClass(DS2,9,1,2)==SUCCESS);
//Line Number: 32
ASSERT_TEST(TimeViewed(DS2,9,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==4);
//Line Number: 33
ASSERT_TEST(WatchClass(DS2,9,0,2)==SUCCESS);
//Line Number: 34
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==2);
//Line Number: 35
ASSERT_TEST(AddCourse(DS2,8,10)==SUCCESS);
//Line Number: 36
ASSERT_TEST(WatchClass(DS2,8,0,19)==SUCCESS);
//Line Number: 37
ASSERT_TEST(TimeViewed(DS2,8,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==19);
//Line Number: 38
ASSERT_TEST(AddCourse(DS2,10,3)==SUCCESS);
//Line Number: 39
ASSERT_TEST(WatchClass(DS2,10,1,17)==SUCCESS);
//Line Number: 40
ASSERT_TEST(TimeViewed(DS2,10,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 41
ASSERT_TEST(WatchClass(DS2,10,1,17)==SUCCESS);
//Line Number: 42
ASSERT_TEST(TimeViewed(DS2,10,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 43
ASSERT_TEST(AddCourse(DS2,10,16)==FAILURE);
//Line Number: 44
ASSERT_TEST(WatchClass(DS2,10,2,10)==SUCCESS);
//Line Number: 45
ASSERT_TEST(TimeViewed(DS2,10,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 46
ASSERT_TEST(WatchClass(DS2,10,1,10)==SUCCESS);
//Line Number: 47
ASSERT_TEST(TimeViewed(DS2,10,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==44);
//Line Number: 48
ASSERT_TEST(WatchClass(DS2,10,1,10)==SUCCESS);
//Line Number: 49
ASSERT_TEST(TimeViewed(DS2,10,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==54);
//Line Number: 50
ASSERT_TEST(AddCourse(DS2,9,15)==FAILURE);
//Line Number: 51
ASSERT_TEST(WatchClass(DS2,9,0,10)==SUCCESS);
//Line Number: 52
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==12);
//Line Number: 53
ASSERT_TEST(WatchClass(DS2,9,0,10)==SUCCESS);
//Line Number: 54
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==22);
//Line Number: 55
ASSERT_TEST(AddCourse(DS2,12,12)==SUCCESS);
//Line Number: 56
ASSERT_TEST(AddCourse(DS2,14,2)==SUCCESS);
//Line Number: 57
ASSERT_TEST(WatchClass(DS2,14,0,19)==SUCCESS);
//Line Number: 58
ASSERT_TEST(TimeViewed(DS2,14,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==19);
//Line Number: 59
ASSERT_TEST(RemoveCourse(DS2,3)==FAILURE);
//Line Number: 60
ASSERT_TEST(WatchClass(DS2,3,9,8)==FAILURE);
//Line Number: 61
ASSERT_TEST(TimeViewed(DS2,3,9,timeviewed)==FAILURE);
//Line Number: 62
ASSERT_TEST(AddCourse(DS2,9,10)==FAILURE);
//Line Number: 63
ASSERT_TEST(WatchClass(DS2,9,0,4)==SUCCESS);
//Line Number: 64
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==26);
//Line Number: 65
ASSERT_TEST(WatchClass(DS2,9,0,4)==SUCCESS);
//Line Number: 66
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==30);
//Line Number: 67
ASSERT_TEST(WatchClass(DS2,9,5,4)==SUCCESS);
//Line Number: 68
ASSERT_TEST(TimeViewed(DS2,9,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==4);
//Line Number: 69
ASSERT_TEST(WatchClass(DS2,9,5,4)==SUCCESS);
//Line Number: 70
ASSERT_TEST(TimeViewed(DS2,9,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 71
ASSERT_TEST(WatchClass(DS2,9,0,4)==SUCCESS);
//Line Number: 72
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 73
ASSERT_TEST(WatchClass(DS2,9,1,4)==SUCCESS);
//Line Number: 74
ASSERT_TEST(TimeViewed(DS2,9,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 75
ASSERT_TEST(AddCourse(DS2,1,2)==SUCCESS);
//Line Number: 76
ASSERT_TEST(WatchClass(DS2,1,0,8)==SUCCESS);
//Line Number: 77
ASSERT_TEST(TimeViewed(DS2,1,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 78
ASSERT_TEST(RemoveCourse(DS2,4)==FAILURE);
//Line Number: 79
ASSERT_TEST(WatchClass(DS2,4,4,3)==FAILURE);
//Line Number: 80
ASSERT_TEST(TimeViewed(DS2,4,4,timeviewed)==FAILURE);
//Line Number: 81
ASSERT_TEST(AddCourse(DS2,18,3)==SUCCESS);
//Line Number: 82
ASSERT_TEST(AddCourse(DS2,16,11)==SUCCESS);
//Line Number: 83
ASSERT_TEST(WatchClass(DS2,16,2,10)==SUCCESS);
//Line Number: 84
ASSERT_TEST(TimeViewed(DS2,16,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 85
ASSERT_TEST(WatchClass(DS2,16,1,10)==SUCCESS);
//Line Number: 86
ASSERT_TEST(TimeViewed(DS2,16,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 87
ASSERT_TEST(WatchClass(DS2,16,4,10)==SUCCESS);
//Line Number: 88
ASSERT_TEST(TimeViewed(DS2,16,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 89
ASSERT_TEST(WatchClass(DS2,16,0,10)==SUCCESS);
//Line Number: 90
ASSERT_TEST(TimeViewed(DS2,16,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 91
ASSERT_TEST(WatchClass(DS2,16,5,10)==SUCCESS);
//Line Number: 92
ASSERT_TEST(TimeViewed(DS2,16,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 93
ASSERT_TEST(WatchClass(DS2,16,4,10)==SUCCESS);
//Line Number: 94
ASSERT_TEST(TimeViewed(DS2,16,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 95
ASSERT_TEST(AddCourse(DS2,17,19)==SUCCESS);
//Line Number: 96
ASSERT_TEST(WatchClass(DS2,17,1,12)==SUCCESS);
//Line Number: 97
ASSERT_TEST(TimeViewed(DS2,17,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==12);
//Line Number: 98
ASSERT_TEST(WatchClass(DS2,17,1,12)==SUCCESS);
//Line Number: 99
ASSERT_TEST(TimeViewed(DS2,17,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==24);
//Line Number: 100
ASSERT_TEST(AddCourse(DS2,11,7)==SUCCESS);
//Line Number: 101
ASSERT_TEST(WatchClass(DS2,11,1,17)==SUCCESS);
//Line Number: 102
ASSERT_TEST(TimeViewed(DS2,11,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 103
ASSERT_TEST(WatchClass(DS2,11,3,17)==SUCCESS);
//Line Number: 104
ASSERT_TEST(TimeViewed(DS2,11,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 105
ASSERT_TEST(WatchClass(DS2,11,2,17)==SUCCESS);
//Line Number: 106
ASSERT_TEST(TimeViewed(DS2,11,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 107
ASSERT_TEST(WatchClass(DS2,11,1,17)==SUCCESS);
//Line Number: 108
ASSERT_TEST(TimeViewed(DS2,11,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 109
ASSERT_TEST(RemoveCourse(DS2,15)==FAILURE);
//Line Number: 110
ASSERT_TEST(WatchClass(DS2,15,5,18)==FAILURE);
//Line Number: 111
ASSERT_TEST(TimeViewed(DS2,15,5,timeviewed)==FAILURE);
//Line Number: 112
ASSERT_TEST(AddCourse(DS2,7,14)==SUCCESS);
//Line Number: 113
ASSERT_TEST(WatchClass(DS2,7,1,17)==SUCCESS);
//Line Number: 114
ASSERT_TEST(TimeViewed(DS2,7,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 115
ASSERT_TEST(WatchClass(DS2,7,1,17)==SUCCESS);
//Line Number: 116
ASSERT_TEST(TimeViewed(DS2,7,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 117
ASSERT_TEST(WatchClass(DS2,7,0,17)==SUCCESS);
//Line Number: 118
ASSERT_TEST(TimeViewed(DS2,7,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 119
ASSERT_TEST(RemoveCourse(DS2,17)==SUCCESS);
//Line Number: 120
ASSERT_TEST(WatchClass(DS2,17,0,18)==FAILURE);
//Line Number: 121
ASSERT_TEST(TimeViewed(DS2,17,0,timeviewed)==FAILURE);
//Line Number: 122
ASSERT_TEST(RemoveCourse(DS2,9)==SUCCESS);
//Line Number: 123
ASSERT_TEST(WatchClass(DS2,9,0,16)==FAILURE);
//Line Number: 124
ASSERT_TEST(TimeViewed(DS2,9,0,timeviewed)==FAILURE);
//Line Number: 125
ASSERT_TEST(AddCourse(DS2,13,17)==SUCCESS);
//Line Number: 126
ASSERT_TEST(WatchClass(DS2,13,4,8)==SUCCESS);
//Line Number: 127
ASSERT_TEST(TimeViewed(DS2,13,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 128
ASSERT_TEST(WatchClass(DS2,13,3,8)==SUCCESS);
//Line Number: 129
ASSERT_TEST(TimeViewed(DS2,13,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 130
ASSERT_TEST(WatchClass(DS2,13,3,8)==SUCCESS);
//Line Number: 131
ASSERT_TEST(TimeViewed(DS2,13,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==16);
//Line Number: 132
ASSERT_TEST(WatchClass(DS2,13,6,8)==SUCCESS);
//Line Number: 133
ASSERT_TEST(TimeViewed(DS2,13,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 134
ASSERT_TEST(WatchClass(DS2,13,5,8)==SUCCESS);
//Line Number: 135
ASSERT_TEST(TimeViewed(DS2,13,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 136
ASSERT_TEST(WatchClass(DS2,13,5,8)==SUCCESS);
//Line Number: 137
ASSERT_TEST(TimeViewed(DS2,13,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==16);
//Line Number: 138
ASSERT_TEST(WatchClass(DS2,13,0,8)==SUCCESS);
//Line Number: 139
ASSERT_TEST(TimeViewed(DS2,13,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 140
ASSERT_TEST(TimeViewed(DS2,1,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 141
ASSERT_TEST(TimeViewed(DS2,1,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 142
ASSERT_TEST(TimeViewed(DS2,7,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 143
ASSERT_TEST(TimeViewed(DS2,7,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 144
ASSERT_TEST(TimeViewed(DS2,7,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 145
ASSERT_TEST(TimeViewed(DS2,7,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 146
ASSERT_TEST(TimeViewed(DS2,7,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 147
ASSERT_TEST(TimeViewed(DS2,7,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 148
ASSERT_TEST(TimeViewed(DS2,7,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 149
ASSERT_TEST(TimeViewed(DS2,7,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 150
ASSERT_TEST(TimeViewed(DS2,7,8,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 151
ASSERT_TEST(TimeViewed(DS2,7,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 152
ASSERT_TEST(TimeViewed(DS2,7,10,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 153
ASSERT_TEST(TimeViewed(DS2,7,11,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 154
ASSERT_TEST(TimeViewed(DS2,7,12,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 155
ASSERT_TEST(TimeViewed(DS2,7,13,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 156
ASSERT_TEST(TimeViewed(DS2,8,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==19);
//Line Number: 157
ASSERT_TEST(TimeViewed(DS2,8,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 158
ASSERT_TEST(TimeViewed(DS2,8,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 159
ASSERT_TEST(TimeViewed(DS2,8,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 160
ASSERT_TEST(TimeViewed(DS2,8,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 161
ASSERT_TEST(TimeViewed(DS2,8,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 162
ASSERT_TEST(TimeViewed(DS2,8,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 163
ASSERT_TEST(TimeViewed(DS2,8,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 164
ASSERT_TEST(TimeViewed(DS2,8,8,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 165
ASSERT_TEST(TimeViewed(DS2,8,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 166
ASSERT_TEST(TimeViewed(DS2,10,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 167
ASSERT_TEST(TimeViewed(DS2,10,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==54);
//Line Number: 168
ASSERT_TEST(TimeViewed(DS2,10,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 169
ASSERT_TEST(TimeViewed(DS2,11,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 170
ASSERT_TEST(TimeViewed(DS2,11,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==34);
//Line Number: 171
ASSERT_TEST(TimeViewed(DS2,11,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 172
ASSERT_TEST(TimeViewed(DS2,11,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==17);
//Line Number: 173
ASSERT_TEST(TimeViewed(DS2,11,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 174
ASSERT_TEST(TimeViewed(DS2,11,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 175
ASSERT_TEST(TimeViewed(DS2,11,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 176
ASSERT_TEST(TimeViewed(DS2,12,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 177
ASSERT_TEST(TimeViewed(DS2,12,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 178
ASSERT_TEST(TimeViewed(DS2,12,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 179
ASSERT_TEST(TimeViewed(DS2,12,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 180
ASSERT_TEST(TimeViewed(DS2,12,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 181
ASSERT_TEST(TimeViewed(DS2,12,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 182
ASSERT_TEST(TimeViewed(DS2,12,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 183
ASSERT_TEST(TimeViewed(DS2,12,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 184
ASSERT_TEST(TimeViewed(DS2,12,8,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 185
ASSERT_TEST(TimeViewed(DS2,12,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 186
ASSERT_TEST(TimeViewed(DS2,12,10,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 187
ASSERT_TEST(TimeViewed(DS2,12,11,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 188
ASSERT_TEST(TimeViewed(DS2,13,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 189
ASSERT_TEST(TimeViewed(DS2,13,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 190
ASSERT_TEST(TimeViewed(DS2,13,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 191
ASSERT_TEST(TimeViewed(DS2,13,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==16);
//Line Number: 192
ASSERT_TEST(TimeViewed(DS2,13,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 193
ASSERT_TEST(TimeViewed(DS2,13,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==16);
//Line Number: 194
ASSERT_TEST(TimeViewed(DS2,13,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 195
ASSERT_TEST(TimeViewed(DS2,13,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 196
ASSERT_TEST(TimeViewed(DS2,13,8,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 197
ASSERT_TEST(TimeViewed(DS2,13,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 198
ASSERT_TEST(TimeViewed(DS2,13,10,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 199
ASSERT_TEST(TimeViewed(DS2,13,11,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 200
ASSERT_TEST(TimeViewed(DS2,13,12,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 201
ASSERT_TEST(TimeViewed(DS2,13,13,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 202
ASSERT_TEST(TimeViewed(DS2,13,14,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 203
ASSERT_TEST(TimeViewed(DS2,13,15,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 204
ASSERT_TEST(TimeViewed(DS2,13,16,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 205
ASSERT_TEST(TimeViewed(DS2,14,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==19);
//Line Number: 206
ASSERT_TEST(TimeViewed(DS2,14,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 207
ASSERT_TEST(TimeViewed(DS2,16,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 208
ASSERT_TEST(TimeViewed(DS2,16,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 209
ASSERT_TEST(TimeViewed(DS2,16,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 210
ASSERT_TEST(TimeViewed(DS2,16,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 211
ASSERT_TEST(TimeViewed(DS2,16,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 212
ASSERT_TEST(TimeViewed(DS2,16,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==10);
//Line Number: 213
ASSERT_TEST(TimeViewed(DS2,16,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 214
ASSERT_TEST(TimeViewed(DS2,16,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 215
ASSERT_TEST(TimeViewed(DS2,16,8,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 216
ASSERT_TEST(TimeViewed(DS2,16,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 217
ASSERT_TEST(TimeViewed(DS2,16,10,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 218
ASSERT_TEST(TimeViewed(DS2,18,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 219
ASSERT_TEST(TimeViewed(DS2,18,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
//Line Number: 220
ASSERT_TEST(TimeViewed(DS2,18,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==0);
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF WATCH TIME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF WATCH TIME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF WATCH TIME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF WATCH TIME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@END OF WATCH TIME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
//Line Number: 221
void *DS3=Init();
//Line Number: 222
ASSERT_TEST(AddCourse(DS3,20,12)==SUCCESS);
classes=new int[1];
courses=new int[1];
//Line Number: 223
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 224
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 225
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 226
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 227
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 228
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 229
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 230
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 231
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 232
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 233
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 234
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 235
ASSERT_TEST(AddCourse(DS3,16,2)==SUCCESS);
//Line Number: 236
ASSERT_TEST(WatchClass(DS3,16,0,18)==SUCCESS);
//Line Number: 237
ASSERT_TEST(TimeViewed(DS3,16,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
classes=new int[1];
courses=new int[1];
//Line Number: 238
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 239
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 240
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 241
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 242
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 243
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 244
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 245
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 246
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 247
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 248
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 249
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 250
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 251
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 252
ASSERT_TEST(AddCourse(DS3,13,5)==SUCCESS);
classes=new int[1];
courses=new int[1];
//Line Number: 253
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 254
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 255
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 256
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 257
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 258
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 259
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 260
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 261
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 262
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 263
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 264
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 265
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 266
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 267
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 268
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 269
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 270
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 271
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 272
ASSERT_TEST(AddCourse(DS3,11,5)==SUCCESS);
//Line Number: 273
ASSERT_TEST(WatchClass(DS3,11,0,15)==SUCCESS);
//Line Number: 274
ASSERT_TEST(TimeViewed(DS3,11,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==15);
//Line Number: 275
ASSERT_TEST(AddCourse(DS3,4,7)==SUCCESS);
//Line Number: 276
ASSERT_TEST(WatchClass(DS3,4,3,20)==SUCCESS);
//Line Number: 277
ASSERT_TEST(TimeViewed(DS3,4,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 278
ASSERT_TEST(WatchClass(DS3,4,3,20)==SUCCESS);
//Line Number: 279
ASSERT_TEST(TimeViewed(DS3,4,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==40);
//Line Number: 280
ASSERT_TEST(WatchClass(DS3,4,3,20)==SUCCESS);
//Line Number: 281
ASSERT_TEST(TimeViewed(DS3,4,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==60);
//Line Number: 282
ASSERT_TEST(WatchClass(DS3,4,4,20)==SUCCESS);
//Line Number: 283
ASSERT_TEST(TimeViewed(DS3,4,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 284
ASSERT_TEST(WatchClass(DS3,4,1,20)==SUCCESS);
//Line Number: 285
ASSERT_TEST(TimeViewed(DS3,4,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 286
ASSERT_TEST(AddCourse(DS3,4,8)==FAILURE);
//Line Number: 287
ASSERT_TEST(WatchClass(DS3,4,2,12)==SUCCESS);
//Line Number: 288
ASSERT_TEST(TimeViewed(DS3,4,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==12);
//Line Number: 289
ASSERT_TEST(WatchClass(DS3,4,3,12)==SUCCESS);
//Line Number: 290
ASSERT_TEST(TimeViewed(DS3,4,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==72);
//Line Number: 291
ASSERT_TEST(WatchClass(DS3,4,0,12)==SUCCESS);
//Line Number: 292
ASSERT_TEST(TimeViewed(DS3,4,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==12);
//Line Number: 293
ASSERT_TEST(WatchClass(DS3,4,2,12)==SUCCESS);
//Line Number: 294
ASSERT_TEST(TimeViewed(DS3,4,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==24);
classes=new int[34];
courses=new int[34];
//Line Number: 295
ASSERT_TEST(GetMostViewedClasses(DS3,34,courses,classes)==FAILURE);
delete[] classes;
delete[] courses;
classes=new int[1];
courses=new int[1];
//Line Number: 296
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 297
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 298
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 299
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 300
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 301
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 302
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 303
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 304
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 305
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 306
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 307
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 308
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 309
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 310
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 311
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 312
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 313
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 314
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 315
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 316
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 317
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 318
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 319
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 320
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 321
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 322
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 323
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 324
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 325
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 326
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 327
ASSERT_TEST(RemoveCourse(DS3,18)==FAILURE);
//Line Number: 328
ASSERT_TEST(WatchClass(DS3,18,0,20)==FAILURE);
//Line Number: 329
ASSERT_TEST(TimeViewed(DS3,18,0,timeviewed)==FAILURE);
classes=new int[1];
courses=new int[1];
//Line Number: 330
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 331
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 332
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 333
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 334
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 335
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 336
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 337
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 338
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 339
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 340
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 341
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 342
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 343
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 344
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 345
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 346
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 347
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 348
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 349
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 350
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 351
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 352
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 353
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 354
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 355
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 356
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 357
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 358
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 359
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 360
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 361
ASSERT_TEST(AddCourse(DS3,10,2)==SUCCESS);
//Line Number: 362
ASSERT_TEST(WatchClass(DS3,10,0,13)==SUCCESS);
//Line Number: 363
ASSERT_TEST(TimeViewed(DS3,10,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
classes=new int[36];
courses=new int[36];
//Line Number: 364
ASSERT_TEST(GetMostViewedClasses(DS3,36,courses,classes)==FAILURE);
delete[] classes;
delete[] courses;
classes=new int[1];
courses=new int[1];
//Line Number: 365
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 366
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 367
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 368
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 369
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 370
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 371
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 372
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 373
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 374
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 375
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 376
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 377
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 378
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 379
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 380
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 381
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 382
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 383
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 384
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 385
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 386
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 387
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 388
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 389
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 390
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 391
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 392
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 393
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 394
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 395
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 396
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 397
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 398
ASSERT_TEST(AddCourse(DS3,20,13)==FAILURE);
//Line Number: 399
ASSERT_TEST(WatchClass(DS3,20,7,20)==SUCCESS);
//Line Number: 400
ASSERT_TEST(TimeViewed(DS3,20,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 401
ASSERT_TEST(WatchClass(DS3,20,5,20)==SUCCESS);
//Line Number: 402
ASSERT_TEST(TimeViewed(DS3,20,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 403
ASSERT_TEST(WatchClass(DS3,20,4,20)==SUCCESS);
//Line Number: 404
ASSERT_TEST(TimeViewed(DS3,20,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 405
ASSERT_TEST(WatchClass(DS3,20,4,20)==SUCCESS);
//Line Number: 406
ASSERT_TEST(TimeViewed(DS3,20,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==40);
//Line Number: 407
ASSERT_TEST(WatchClass(DS3,20,7,20)==SUCCESS);
//Line Number: 408
ASSERT_TEST(TimeViewed(DS3,20,7,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==40);
//Line Number: 409
ASSERT_TEST(WatchClass(DS3,20,1,20)==SUCCESS);
//Line Number: 410
ASSERT_TEST(TimeViewed(DS3,20,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
//Line Number: 411
ASSERT_TEST(WatchClass(DS3,20,1,20)==SUCCESS);
//Line Number: 412
ASSERT_TEST(TimeViewed(DS3,20,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==40);
//Line Number: 413
ASSERT_TEST(WatchClass(DS3,20,3,20)==SUCCESS);
//Line Number: 414
ASSERT_TEST(TimeViewed(DS3,20,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==20);
classes=new int[1];
courses=new int[1];
//Line Number: 415
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 416
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 417
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 418
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 419
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 420
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 421
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 422
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 423
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 424
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 425
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 426
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 427
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 428
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 429
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 430
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 431
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 432
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 433
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 434
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 435
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 436
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 437
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 438
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 439
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 440
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 441
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 442
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 443
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 444
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 445
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 446
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 447
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 448
ASSERT_TEST(AddCourse(DS3,13,3)==FAILURE);
//Line Number: 449
ASSERT_TEST(WatchClass(DS3,13,0,8)==SUCCESS);
//Line Number: 450
ASSERT_TEST(TimeViewed(DS3,13,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==8);
//Line Number: 451
ASSERT_TEST(WatchClass(DS3,13,0,8)==SUCCESS);
//Line Number: 452
ASSERT_TEST(TimeViewed(DS3,13,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==16);
classes=new int[9];
courses=new int[9];
//Line Number: 453
ASSERT_TEST(GetMostViewedClasses(DS3,-2,courses,classes)==INVALID_INPUT);
delete[] classes;
delete[] courses;
classes=new int[1];
courses=new int[1];
//Line Number: 454
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 455
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 456
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 457
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 458
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 459
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 460
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 461
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 462
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 463
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 464
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 465
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 466
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 467
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 468
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 469
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 470
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 471
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 472
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 473
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 474
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 475
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 476
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 477
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 478
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 479
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 480
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 481
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 482
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 483
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 484
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 485
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 486
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 487
ASSERT_TEST(AddCourse(DS3,8,8)==SUCCESS);
//Line Number: 488
ASSERT_TEST(WatchClass(DS3,8,1,5)==SUCCESS);
//Line Number: 489
ASSERT_TEST(TimeViewed(DS3,8,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==5);
//Line Number: 490
ASSERT_TEST(WatchClass(DS3,8,2,5)==SUCCESS);
//Line Number: 491
ASSERT_TEST(TimeViewed(DS3,8,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==5);
//Line Number: 492
ASSERT_TEST(WatchClass(DS3,8,0,5)==SUCCESS);
//Line Number: 493
ASSERT_TEST(TimeViewed(DS3,8,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==5);
//Line Number: 494
ASSERT_TEST(AddCourse(DS3,8,18)==FAILURE);
//Line Number: 495
ASSERT_TEST(WatchClass(DS3,8,1,19)==SUCCESS);
//Line Number: 496
ASSERT_TEST(TimeViewed(DS3,8,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==24);
//Line Number: 497
ASSERT_TEST(WatchClass(DS3,8,1,19)==SUCCESS);
//Line Number: 498
ASSERT_TEST(TimeViewed(DS3,8,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==43);
//Line Number: 499
ASSERT_TEST(WatchClass(DS3,8,1,19)==SUCCESS);
//Line Number: 500
ASSERT_TEST(TimeViewed(DS3,8,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==62);
classes=new int[11];
courses=new int[11];
//Line Number: 501
ASSERT_TEST(GetMostViewedClasses(DS3,-1,courses,classes)==INVALID_INPUT);
delete[] classes;
delete[] courses;
classes=new int[1];
courses=new int[1];
//Line Number: 502
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 503
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 504
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 505
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 506
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 507
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 508
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 509
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 510
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 511
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 512
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 513
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 514
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 515
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 516
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 517
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 518
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 519
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 520
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 521
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 522
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 523
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 524
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 525
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 526
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 527
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 528
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 529
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 530
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 531
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 532
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 533
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 534
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[34];
courses=new int[34];
//Line Number: 535
ASSERT_TEST(GetMostViewedClasses(DS3,34,courses,classes)==SUCCESS);
printFunc(34,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[35];
courses=new int[35];
//Line Number: 536
ASSERT_TEST(GetMostViewedClasses(DS3,35,courses,classes)==SUCCESS);
printFunc(35,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[36];
courses=new int[36];
//Line Number: 537
ASSERT_TEST(GetMostViewedClasses(DS3,36,courses,classes)==SUCCESS);
printFunc(36,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[37];
courses=new int[37];
//Line Number: 538
ASSERT_TEST(GetMostViewedClasses(DS3,37,courses,classes)==SUCCESS);
printFunc(37,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[38];
courses=new int[38];
//Line Number: 539
ASSERT_TEST(GetMostViewedClasses(DS3,38,courses,classes)==SUCCESS);
printFunc(38,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[39];
courses=new int[39];
//Line Number: 540
ASSERT_TEST(GetMostViewedClasses(DS3,39,courses,classes)==SUCCESS);
printFunc(39,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[40];
courses=new int[40];
//Line Number: 541
ASSERT_TEST(GetMostViewedClasses(DS3,40,courses,classes)==SUCCESS);
printFunc(40,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[41];
courses=new int[41];
//Line Number: 542
ASSERT_TEST(GetMostViewedClasses(DS3,41,courses,classes)==SUCCESS);
printFunc(41,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 543
ASSERT_TEST(AddCourse(DS3,9,7)==SUCCESS);
//Line Number: 544
ASSERT_TEST(WatchClass(DS3,9,1,1)==SUCCESS);
//Line Number: 545
ASSERT_TEST(TimeViewed(DS3,9,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==1);
//Line Number: 546
ASSERT_TEST(WatchClass(DS3,9,0,1)==SUCCESS);
//Line Number: 547
ASSERT_TEST(TimeViewed(DS3,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==1);
//Line Number: 548
ASSERT_TEST(WatchClass(DS3,9,0,1)==SUCCESS);
//Line Number: 549
ASSERT_TEST(TimeViewed(DS3,9,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==2);
//Line Number: 550
ASSERT_TEST(WatchClass(DS3,9,1,1)==SUCCESS);
//Line Number: 551
ASSERT_TEST(TimeViewed(DS3,9,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==2);
classes=new int[1];
courses=new int[1];
//Line Number: 552
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 553
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 554
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 555
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 556
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 557
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 558
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 559
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 560
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 561
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 562
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 563
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 564
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 565
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 566
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 567
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 568
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 569
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 570
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 571
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 572
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 573
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 574
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 575
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 576
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 577
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 578
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 579
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 580
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 581
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 582
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 583
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 584
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[34];
courses=new int[34];
//Line Number: 585
ASSERT_TEST(GetMostViewedClasses(DS3,34,courses,classes)==SUCCESS);
printFunc(34,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[35];
courses=new int[35];
//Line Number: 586
ASSERT_TEST(GetMostViewedClasses(DS3,35,courses,classes)==SUCCESS);
printFunc(35,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[36];
courses=new int[36];
//Line Number: 587
ASSERT_TEST(GetMostViewedClasses(DS3,36,courses,classes)==SUCCESS);
printFunc(36,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[37];
courses=new int[37];
//Line Number: 588
ASSERT_TEST(GetMostViewedClasses(DS3,37,courses,classes)==SUCCESS);
printFunc(37,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[38];
courses=new int[38];
//Line Number: 589
ASSERT_TEST(GetMostViewedClasses(DS3,38,courses,classes)==SUCCESS);
printFunc(38,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[39];
courses=new int[39];
//Line Number: 590
ASSERT_TEST(GetMostViewedClasses(DS3,39,courses,classes)==SUCCESS);
printFunc(39,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[40];
courses=new int[40];
//Line Number: 591
ASSERT_TEST(GetMostViewedClasses(DS3,40,courses,classes)==SUCCESS);
printFunc(40,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[41];
courses=new int[41];
//Line Number: 592
ASSERT_TEST(GetMostViewedClasses(DS3,41,courses,classes)==SUCCESS);
printFunc(41,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[42];
courses=new int[42];
//Line Number: 593
ASSERT_TEST(GetMostViewedClasses(DS3,42,courses,classes)==SUCCESS);
printFunc(42,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[43];
courses=new int[43];
//Line Number: 594
ASSERT_TEST(GetMostViewedClasses(DS3,43,courses,classes)==SUCCESS);
printFunc(43,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[44];
courses=new int[44];
//Line Number: 595
ASSERT_TEST(GetMostViewedClasses(DS3,44,courses,classes)==SUCCESS);
printFunc(44,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[45];
courses=new int[45];
//Line Number: 596
ASSERT_TEST(GetMostViewedClasses(DS3,45,courses,classes)==SUCCESS);
printFunc(45,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[46];
courses=new int[46];
//Line Number: 597
ASSERT_TEST(GetMostViewedClasses(DS3,46,courses,classes)==SUCCESS);
printFunc(46,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[47];
courses=new int[47];
//Line Number: 598
ASSERT_TEST(GetMostViewedClasses(DS3,47,courses,classes)==SUCCESS);
printFunc(47,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[48];
courses=new int[48];
//Line Number: 599
ASSERT_TEST(GetMostViewedClasses(DS3,48,courses,classes)==SUCCESS);
printFunc(48,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 600
ASSERT_TEST(AddCourse(DS3,7,11)==SUCCESS);
//Line Number: 601
ASSERT_TEST(WatchClass(DS3,7,6,9)==SUCCESS);
//Line Number: 602
ASSERT_TEST(TimeViewed(DS3,7,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 603
ASSERT_TEST(WatchClass(DS3,7,5,9)==SUCCESS);
//Line Number: 604
ASSERT_TEST(TimeViewed(DS3,7,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 605
ASSERT_TEST(WatchClass(DS3,7,5,9)==SUCCESS);
//Line Number: 606
ASSERT_TEST(TimeViewed(DS3,7,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 607
ASSERT_TEST(WatchClass(DS3,7,4,9)==SUCCESS);
//Line Number: 608
ASSERT_TEST(TimeViewed(DS3,7,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 609
ASSERT_TEST(WatchClass(DS3,7,1,9)==SUCCESS);
//Line Number: 610
ASSERT_TEST(TimeViewed(DS3,7,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 611
ASSERT_TEST(WatchClass(DS3,7,3,9)==SUCCESS);
//Line Number: 612
ASSERT_TEST(TimeViewed(DS3,7,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 613
ASSERT_TEST(WatchClass(DS3,7,4,9)==SUCCESS);
//Line Number: 614
ASSERT_TEST(TimeViewed(DS3,7,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 615
ASSERT_TEST(AddCourse(DS3,11,10)==FAILURE);
//Line Number: 616
ASSERT_TEST(WatchClass(DS3,11,0,18)==SUCCESS);
//Line Number: 617
ASSERT_TEST(TimeViewed(DS3,11,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==33);
//Line Number: 618
ASSERT_TEST(WatchClass(DS3,11,0,18)==SUCCESS);
//Line Number: 619
ASSERT_TEST(TimeViewed(DS3,11,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==51);
//Line Number: 620
ASSERT_TEST(WatchClass(DS3,11,2,18)==SUCCESS);
//Line Number: 621
ASSERT_TEST(TimeViewed(DS3,11,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 622
ASSERT_TEST(WatchClass(DS3,11,1,18)==SUCCESS);
//Line Number: 623
ASSERT_TEST(TimeViewed(DS3,11,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 624
ASSERT_TEST(WatchClass(DS3,11,3,18)==SUCCESS);
//Line Number: 625
ASSERT_TEST(TimeViewed(DS3,11,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 626
ASSERT_TEST(AddCourse(DS3,6,17)==SUCCESS);
//Line Number: 627
ASSERT_TEST(WatchClass(DS3,6,0,9)==SUCCESS);
//Line Number: 628
ASSERT_TEST(TimeViewed(DS3,6,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==9);
//Line Number: 629
ASSERT_TEST(AddCourse(DS3,3,3)==SUCCESS);
//Line Number: 630
ASSERT_TEST(WatchClass(DS3,3,0,18)==SUCCESS);
//Line Number: 631
ASSERT_TEST(TimeViewed(DS3,3,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 632
ASSERT_TEST(WatchClass(DS3,3,1,18)==SUCCESS);
//Line Number: 633
ASSERT_TEST(TimeViewed(DS3,3,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
classes=new int[1];
courses=new int[1];
//Line Number: 634
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 635
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 636
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 637
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 638
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 639
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 640
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 641
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 642
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 643
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 644
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 645
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 646
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 647
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 648
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 649
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 650
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 651
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 652
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 653
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 654
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 655
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 656
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 657
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 658
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 659
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 660
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 661
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 662
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 663
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 664
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 665
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 666
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[34];
courses=new int[34];
//Line Number: 667
ASSERT_TEST(GetMostViewedClasses(DS3,34,courses,classes)==SUCCESS);
printFunc(34,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[35];
courses=new int[35];
//Line Number: 668
ASSERT_TEST(GetMostViewedClasses(DS3,35,courses,classes)==SUCCESS);
printFunc(35,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[36];
courses=new int[36];
//Line Number: 669
ASSERT_TEST(GetMostViewedClasses(DS3,36,courses,classes)==SUCCESS);
printFunc(36,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[37];
courses=new int[37];
//Line Number: 670
ASSERT_TEST(GetMostViewedClasses(DS3,37,courses,classes)==SUCCESS);
printFunc(37,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[38];
courses=new int[38];
//Line Number: 671
ASSERT_TEST(GetMostViewedClasses(DS3,38,courses,classes)==SUCCESS);
printFunc(38,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[39];
courses=new int[39];
//Line Number: 672
ASSERT_TEST(GetMostViewedClasses(DS3,39,courses,classes)==SUCCESS);
printFunc(39,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[40];
courses=new int[40];
//Line Number: 673
ASSERT_TEST(GetMostViewedClasses(DS3,40,courses,classes)==SUCCESS);
printFunc(40,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[41];
courses=new int[41];
//Line Number: 674
ASSERT_TEST(GetMostViewedClasses(DS3,41,courses,classes)==SUCCESS);
printFunc(41,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[42];
courses=new int[42];
//Line Number: 675
ASSERT_TEST(GetMostViewedClasses(DS3,42,courses,classes)==SUCCESS);
printFunc(42,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[43];
courses=new int[43];
//Line Number: 676
ASSERT_TEST(GetMostViewedClasses(DS3,43,courses,classes)==SUCCESS);
printFunc(43,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[44];
courses=new int[44];
//Line Number: 677
ASSERT_TEST(GetMostViewedClasses(DS3,44,courses,classes)==SUCCESS);
printFunc(44,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[45];
courses=new int[45];
//Line Number: 678
ASSERT_TEST(GetMostViewedClasses(DS3,45,courses,classes)==SUCCESS);
printFunc(45,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[46];
courses=new int[46];
//Line Number: 679
ASSERT_TEST(GetMostViewedClasses(DS3,46,courses,classes)==SUCCESS);
printFunc(46,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[47];
courses=new int[47];
//Line Number: 680
ASSERT_TEST(GetMostViewedClasses(DS3,47,courses,classes)==SUCCESS);
printFunc(47,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[48];
courses=new int[48];
//Line Number: 681
ASSERT_TEST(GetMostViewedClasses(DS3,48,courses,classes)==SUCCESS);
printFunc(48,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[49];
courses=new int[49];
//Line Number: 682
ASSERT_TEST(GetMostViewedClasses(DS3,49,courses,classes)==SUCCESS);
printFunc(49,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[50];
courses=new int[50];
//Line Number: 683
ASSERT_TEST(GetMostViewedClasses(DS3,50,courses,classes)==SUCCESS);
printFunc(50,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[51];
courses=new int[51];
//Line Number: 684
ASSERT_TEST(GetMostViewedClasses(DS3,51,courses,classes)==SUCCESS);
printFunc(51,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[52];
courses=new int[52];
//Line Number: 685
ASSERT_TEST(GetMostViewedClasses(DS3,52,courses,classes)==SUCCESS);
printFunc(52,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[53];
courses=new int[53];
//Line Number: 686
ASSERT_TEST(GetMostViewedClasses(DS3,53,courses,classes)==SUCCESS);
printFunc(53,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[54];
courses=new int[54];
//Line Number: 687
ASSERT_TEST(GetMostViewedClasses(DS3,54,courses,classes)==SUCCESS);
printFunc(54,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[55];
courses=new int[55];
//Line Number: 688
ASSERT_TEST(GetMostViewedClasses(DS3,55,courses,classes)==SUCCESS);
printFunc(55,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[56];
courses=new int[56];
//Line Number: 689
ASSERT_TEST(GetMostViewedClasses(DS3,56,courses,classes)==SUCCESS);
printFunc(56,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[57];
courses=new int[57];
//Line Number: 690
ASSERT_TEST(GetMostViewedClasses(DS3,57,courses,classes)==SUCCESS);
printFunc(57,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[58];
courses=new int[58];
//Line Number: 691
ASSERT_TEST(GetMostViewedClasses(DS3,58,courses,classes)==SUCCESS);
printFunc(58,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[59];
courses=new int[59];
//Line Number: 692
ASSERT_TEST(GetMostViewedClasses(DS3,59,courses,classes)==SUCCESS);
printFunc(59,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[60];
courses=new int[60];
//Line Number: 693
ASSERT_TEST(GetMostViewedClasses(DS3,60,courses,classes)==SUCCESS);
printFunc(60,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[61];
courses=new int[61];
//Line Number: 694
ASSERT_TEST(GetMostViewedClasses(DS3,61,courses,classes)==SUCCESS);
printFunc(61,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[62];
courses=new int[62];
//Line Number: 695
ASSERT_TEST(GetMostViewedClasses(DS3,62,courses,classes)==SUCCESS);
printFunc(62,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[63];
courses=new int[63];
//Line Number: 696
ASSERT_TEST(GetMostViewedClasses(DS3,63,courses,classes)==SUCCESS);
printFunc(63,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[64];
courses=new int[64];
//Line Number: 697
ASSERT_TEST(GetMostViewedClasses(DS3,64,courses,classes)==SUCCESS);
printFunc(64,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[65];
courses=new int[65];
//Line Number: 698
ASSERT_TEST(GetMostViewedClasses(DS3,65,courses,classes)==SUCCESS);
printFunc(65,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[66];
courses=new int[66];
//Line Number: 699
ASSERT_TEST(GetMostViewedClasses(DS3,66,courses,classes)==SUCCESS);
printFunc(66,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[67];
courses=new int[67];
//Line Number: 700
ASSERT_TEST(GetMostViewedClasses(DS3,67,courses,classes)==SUCCESS);
printFunc(67,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[68];
courses=new int[68];
//Line Number: 701
ASSERT_TEST(GetMostViewedClasses(DS3,68,courses,classes)==SUCCESS);
printFunc(68,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[69];
courses=new int[69];
//Line Number: 702
ASSERT_TEST(GetMostViewedClasses(DS3,69,courses,classes)==SUCCESS);
printFunc(69,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[70];
courses=new int[70];
//Line Number: 703
ASSERT_TEST(GetMostViewedClasses(DS3,70,courses,classes)==SUCCESS);
printFunc(70,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[71];
courses=new int[71];
//Line Number: 704
ASSERT_TEST(GetMostViewedClasses(DS3,71,courses,classes)==SUCCESS);
printFunc(71,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[72];
courses=new int[72];
//Line Number: 705
ASSERT_TEST(GetMostViewedClasses(DS3,72,courses,classes)==SUCCESS);
printFunc(72,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[73];
courses=new int[73];
//Line Number: 706
ASSERT_TEST(GetMostViewedClasses(DS3,73,courses,classes)==SUCCESS);
printFunc(73,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[74];
courses=new int[74];
//Line Number: 707
ASSERT_TEST(GetMostViewedClasses(DS3,74,courses,classes)==SUCCESS);
printFunc(74,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[75];
courses=new int[75];
//Line Number: 708
ASSERT_TEST(GetMostViewedClasses(DS3,75,courses,classes)==SUCCESS);
printFunc(75,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[76];
courses=new int[76];
//Line Number: 709
ASSERT_TEST(GetMostViewedClasses(DS3,76,courses,classes)==SUCCESS);
printFunc(76,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[77];
courses=new int[77];
//Line Number: 710
ASSERT_TEST(GetMostViewedClasses(DS3,77,courses,classes)==SUCCESS);
printFunc(77,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[78];
courses=new int[78];
//Line Number: 711
ASSERT_TEST(GetMostViewedClasses(DS3,78,courses,classes)==SUCCESS);
printFunc(78,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[79];
courses=new int[79];
//Line Number: 712
ASSERT_TEST(GetMostViewedClasses(DS3,79,courses,classes)==SUCCESS);
printFunc(79,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 713
ASSERT_TEST(AddCourse(DS3,18,19)==SUCCESS);
//Line Number: 714
ASSERT_TEST(WatchClass(DS3,18,9,13)==SUCCESS);
//Line Number: 715
ASSERT_TEST(TimeViewed(DS3,18,9,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 716
ASSERT_TEST(WatchClass(DS3,18,5,13)==SUCCESS);
//Line Number: 717
ASSERT_TEST(TimeViewed(DS3,18,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 718
ASSERT_TEST(WatchClass(DS3,18,3,13)==SUCCESS);
//Line Number: 719
ASSERT_TEST(TimeViewed(DS3,18,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 720
ASSERT_TEST(WatchClass(DS3,18,2,13)==SUCCESS);
//Line Number: 721
ASSERT_TEST(TimeViewed(DS3,18,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 722
ASSERT_TEST(WatchClass(DS3,18,5,13)==SUCCESS);
//Line Number: 723
ASSERT_TEST(TimeViewed(DS3,18,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==26);
//Line Number: 724
ASSERT_TEST(WatchClass(DS3,18,4,13)==SUCCESS);
//Line Number: 725
ASSERT_TEST(TimeViewed(DS3,18,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 726
ASSERT_TEST(WatchClass(DS3,18,1,13)==SUCCESS);
//Line Number: 727
ASSERT_TEST(TimeViewed(DS3,18,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 728
ASSERT_TEST(WatchClass(DS3,18,5,13)==SUCCESS);
//Line Number: 729
ASSERT_TEST(TimeViewed(DS3,18,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==39);
//Line Number: 730
ASSERT_TEST(WatchClass(DS3,18,6,13)==SUCCESS);
//Line Number: 731
ASSERT_TEST(TimeViewed(DS3,18,6,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==13);
//Line Number: 732
ASSERT_TEST(WatchClass(DS3,18,2,13)==SUCCESS);
//Line Number: 733
ASSERT_TEST(TimeViewed(DS3,18,2,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==26);
//Line Number: 734
ASSERT_TEST(WatchClass(DS3,18,5,13)==SUCCESS);
//Line Number: 735
ASSERT_TEST(TimeViewed(DS3,18,5,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==52);
//Line Number: 736
ASSERT_TEST(WatchClass(DS3,18,4,13)==SUCCESS);
//Line Number: 737
ASSERT_TEST(TimeViewed(DS3,18,4,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==26);
//Line Number: 738
ASSERT_TEST(WatchClass(DS3,18,3,13)==SUCCESS);
//Line Number: 739
ASSERT_TEST(TimeViewed(DS3,18,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==26);
classes=new int[1];
courses=new int[1];
//Line Number: 740
ASSERT_TEST(GetMostViewedClasses(DS3,1,courses,classes)==SUCCESS);
printFunc(1,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[2];
courses=new int[2];
//Line Number: 741
ASSERT_TEST(GetMostViewedClasses(DS3,2,courses,classes)==SUCCESS);
printFunc(2,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[3];
courses=new int[3];
//Line Number: 742
ASSERT_TEST(GetMostViewedClasses(DS3,3,courses,classes)==SUCCESS);
printFunc(3,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[4];
courses=new int[4];
//Line Number: 743
ASSERT_TEST(GetMostViewedClasses(DS3,4,courses,classes)==SUCCESS);
printFunc(4,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[5];
courses=new int[5];
//Line Number: 744
ASSERT_TEST(GetMostViewedClasses(DS3,5,courses,classes)==SUCCESS);
printFunc(5,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[6];
courses=new int[6];
//Line Number: 745
ASSERT_TEST(GetMostViewedClasses(DS3,6,courses,classes)==SUCCESS);
printFunc(6,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[7];
courses=new int[7];
//Line Number: 746
ASSERT_TEST(GetMostViewedClasses(DS3,7,courses,classes)==SUCCESS);
printFunc(7,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[8];
courses=new int[8];
//Line Number: 747
ASSERT_TEST(GetMostViewedClasses(DS3,8,courses,classes)==SUCCESS);
printFunc(8,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[9];
courses=new int[9];
//Line Number: 748
ASSERT_TEST(GetMostViewedClasses(DS3,9,courses,classes)==SUCCESS);
printFunc(9,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[10];
courses=new int[10];
//Line Number: 749
ASSERT_TEST(GetMostViewedClasses(DS3,10,courses,classes)==SUCCESS);
printFunc(10,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[11];
courses=new int[11];
//Line Number: 750
ASSERT_TEST(GetMostViewedClasses(DS3,11,courses,classes)==SUCCESS);
printFunc(11,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[12];
courses=new int[12];
//Line Number: 751
ASSERT_TEST(GetMostViewedClasses(DS3,12,courses,classes)==SUCCESS);
printFunc(12,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[13];
courses=new int[13];
//Line Number: 752
ASSERT_TEST(GetMostViewedClasses(DS3,13,courses,classes)==SUCCESS);
printFunc(13,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[14];
courses=new int[14];
//Line Number: 753
ASSERT_TEST(GetMostViewedClasses(DS3,14,courses,classes)==SUCCESS);
printFunc(14,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[15];
courses=new int[15];
//Line Number: 754
ASSERT_TEST(GetMostViewedClasses(DS3,15,courses,classes)==SUCCESS);
printFunc(15,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[16];
courses=new int[16];
//Line Number: 755
ASSERT_TEST(GetMostViewedClasses(DS3,16,courses,classes)==SUCCESS);
printFunc(16,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[17];
courses=new int[17];
//Line Number: 756
ASSERT_TEST(GetMostViewedClasses(DS3,17,courses,classes)==SUCCESS);
printFunc(17,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[18];
courses=new int[18];
//Line Number: 757
ASSERT_TEST(GetMostViewedClasses(DS3,18,courses,classes)==SUCCESS);
printFunc(18,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[19];
courses=new int[19];
//Line Number: 758
ASSERT_TEST(GetMostViewedClasses(DS3,19,courses,classes)==SUCCESS);
printFunc(19,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[20];
courses=new int[20];
//Line Number: 759
ASSERT_TEST(GetMostViewedClasses(DS3,20,courses,classes)==SUCCESS);
printFunc(20,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[21];
courses=new int[21];
//Line Number: 760
ASSERT_TEST(GetMostViewedClasses(DS3,21,courses,classes)==SUCCESS);
printFunc(21,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[22];
courses=new int[22];
//Line Number: 761
ASSERT_TEST(GetMostViewedClasses(DS3,22,courses,classes)==SUCCESS);
printFunc(22,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[23];
courses=new int[23];
//Line Number: 762
ASSERT_TEST(GetMostViewedClasses(DS3,23,courses,classes)==SUCCESS);
printFunc(23,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[24];
courses=new int[24];
//Line Number: 763
ASSERT_TEST(GetMostViewedClasses(DS3,24,courses,classes)==SUCCESS);
printFunc(24,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[25];
courses=new int[25];
//Line Number: 764
ASSERT_TEST(GetMostViewedClasses(DS3,25,courses,classes)==SUCCESS);
printFunc(25,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[26];
courses=new int[26];
//Line Number: 765
ASSERT_TEST(GetMostViewedClasses(DS3,26,courses,classes)==SUCCESS);
printFunc(26,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[27];
courses=new int[27];
//Line Number: 766
ASSERT_TEST(GetMostViewedClasses(DS3,27,courses,classes)==SUCCESS);
printFunc(27,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[28];
courses=new int[28];
//Line Number: 767
ASSERT_TEST(GetMostViewedClasses(DS3,28,courses,classes)==SUCCESS);
printFunc(28,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[29];
courses=new int[29];
//Line Number: 768
ASSERT_TEST(GetMostViewedClasses(DS3,29,courses,classes)==SUCCESS);
printFunc(29,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[30];
courses=new int[30];
//Line Number: 769
ASSERT_TEST(GetMostViewedClasses(DS3,30,courses,classes)==SUCCESS);
printFunc(30,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[31];
courses=new int[31];
//Line Number: 770
ASSERT_TEST(GetMostViewedClasses(DS3,31,courses,classes)==SUCCESS);
printFunc(31,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[32];
courses=new int[32];
//Line Number: 771
ASSERT_TEST(GetMostViewedClasses(DS3,32,courses,classes)==SUCCESS);
printFunc(32,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[33];
courses=new int[33];
//Line Number: 772
ASSERT_TEST(GetMostViewedClasses(DS3,33,courses,classes)==SUCCESS);
printFunc(33,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[34];
courses=new int[34];
//Line Number: 773
ASSERT_TEST(GetMostViewedClasses(DS3,34,courses,classes)==SUCCESS);
printFunc(34,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[35];
courses=new int[35];
//Line Number: 774
ASSERT_TEST(GetMostViewedClasses(DS3,35,courses,classes)==SUCCESS);
printFunc(35,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[36];
courses=new int[36];
//Line Number: 775
ASSERT_TEST(GetMostViewedClasses(DS3,36,courses,classes)==SUCCESS);
printFunc(36,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[37];
courses=new int[37];
//Line Number: 776
ASSERT_TEST(GetMostViewedClasses(DS3,37,courses,classes)==SUCCESS);
printFunc(37,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[38];
courses=new int[38];
//Line Number: 777
ASSERT_TEST(GetMostViewedClasses(DS3,38,courses,classes)==SUCCESS);
printFunc(38,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[39];
courses=new int[39];
//Line Number: 778
ASSERT_TEST(GetMostViewedClasses(DS3,39,courses,classes)==SUCCESS);
printFunc(39,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[40];
courses=new int[40];
//Line Number: 779
ASSERT_TEST(GetMostViewedClasses(DS3,40,courses,classes)==SUCCESS);
printFunc(40,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[41];
courses=new int[41];
//Line Number: 780
ASSERT_TEST(GetMostViewedClasses(DS3,41,courses,classes)==SUCCESS);
printFunc(41,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[42];
courses=new int[42];
//Line Number: 781
ASSERT_TEST(GetMostViewedClasses(DS3,42,courses,classes)==SUCCESS);
printFunc(42,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[43];
courses=new int[43];
//Line Number: 782
ASSERT_TEST(GetMostViewedClasses(DS3,43,courses,classes)==SUCCESS);
printFunc(43,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[44];
courses=new int[44];
//Line Number: 783
ASSERT_TEST(GetMostViewedClasses(DS3,44,courses,classes)==SUCCESS);
printFunc(44,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[45];
courses=new int[45];
//Line Number: 784
ASSERT_TEST(GetMostViewedClasses(DS3,45,courses,classes)==SUCCESS);
printFunc(45,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[46];
courses=new int[46];
//Line Number: 785
ASSERT_TEST(GetMostViewedClasses(DS3,46,courses,classes)==SUCCESS);
printFunc(46,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[47];
courses=new int[47];
//Line Number: 786
ASSERT_TEST(GetMostViewedClasses(DS3,47,courses,classes)==SUCCESS);
printFunc(47,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[48];
courses=new int[48];
//Line Number: 787
ASSERT_TEST(GetMostViewedClasses(DS3,48,courses,classes)==SUCCESS);
printFunc(48,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[49];
courses=new int[49];
//Line Number: 788
ASSERT_TEST(GetMostViewedClasses(DS3,49,courses,classes)==SUCCESS);
printFunc(49,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[50];
courses=new int[50];
//Line Number: 789
ASSERT_TEST(GetMostViewedClasses(DS3,50,courses,classes)==SUCCESS);
printFunc(50,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[51];
courses=new int[51];
//Line Number: 790
ASSERT_TEST(GetMostViewedClasses(DS3,51,courses,classes)==SUCCESS);
printFunc(51,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[52];
courses=new int[52];
//Line Number: 791
ASSERT_TEST(GetMostViewedClasses(DS3,52,courses,classes)==SUCCESS);
printFunc(52,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[53];
courses=new int[53];
//Line Number: 792
ASSERT_TEST(GetMostViewedClasses(DS3,53,courses,classes)==SUCCESS);
printFunc(53,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[54];
courses=new int[54];
//Line Number: 793
ASSERT_TEST(GetMostViewedClasses(DS3,54,courses,classes)==SUCCESS);
printFunc(54,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[55];
courses=new int[55];
//Line Number: 794
ASSERT_TEST(GetMostViewedClasses(DS3,55,courses,classes)==SUCCESS);
printFunc(55,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[56];
courses=new int[56];
//Line Number: 795
ASSERT_TEST(GetMostViewedClasses(DS3,56,courses,classes)==SUCCESS);
printFunc(56,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[57];
courses=new int[57];
//Line Number: 796
ASSERT_TEST(GetMostViewedClasses(DS3,57,courses,classes)==SUCCESS);
printFunc(57,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[58];
courses=new int[58];
//Line Number: 797
ASSERT_TEST(GetMostViewedClasses(DS3,58,courses,classes)==SUCCESS);
printFunc(58,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[59];
courses=new int[59];
//Line Number: 798
ASSERT_TEST(GetMostViewedClasses(DS3,59,courses,classes)==SUCCESS);
printFunc(59,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[60];
courses=new int[60];
//Line Number: 799
ASSERT_TEST(GetMostViewedClasses(DS3,60,courses,classes)==SUCCESS);
printFunc(60,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[61];
courses=new int[61];
//Line Number: 800
ASSERT_TEST(GetMostViewedClasses(DS3,61,courses,classes)==SUCCESS);
printFunc(61,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[62];
courses=new int[62];
//Line Number: 801
ASSERT_TEST(GetMostViewedClasses(DS3,62,courses,classes)==SUCCESS);
printFunc(62,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[63];
courses=new int[63];
//Line Number: 802
ASSERT_TEST(GetMostViewedClasses(DS3,63,courses,classes)==SUCCESS);
printFunc(63,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[64];
courses=new int[64];
//Line Number: 803
ASSERT_TEST(GetMostViewedClasses(DS3,64,courses,classes)==SUCCESS);
printFunc(64,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[65];
courses=new int[65];
//Line Number: 804
ASSERT_TEST(GetMostViewedClasses(DS3,65,courses,classes)==SUCCESS);
printFunc(65,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[66];
courses=new int[66];
//Line Number: 805
ASSERT_TEST(GetMostViewedClasses(DS3,66,courses,classes)==SUCCESS);
printFunc(66,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[67];
courses=new int[67];
//Line Number: 806
ASSERT_TEST(GetMostViewedClasses(DS3,67,courses,classes)==SUCCESS);
printFunc(67,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[68];
courses=new int[68];
//Line Number: 807
ASSERT_TEST(GetMostViewedClasses(DS3,68,courses,classes)==SUCCESS);
printFunc(68,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[69];
courses=new int[69];
//Line Number: 808
ASSERT_TEST(GetMostViewedClasses(DS3,69,courses,classes)==SUCCESS);
printFunc(69,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[70];
courses=new int[70];
//Line Number: 809
ASSERT_TEST(GetMostViewedClasses(DS3,70,courses,classes)==SUCCESS);
printFunc(70,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[71];
courses=new int[71];
//Line Number: 810
ASSERT_TEST(GetMostViewedClasses(DS3,71,courses,classes)==SUCCESS);
printFunc(71,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[72];
courses=new int[72];
//Line Number: 811
ASSERT_TEST(GetMostViewedClasses(DS3,72,courses,classes)==SUCCESS);
printFunc(72,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[73];
courses=new int[73];
//Line Number: 812
ASSERT_TEST(GetMostViewedClasses(DS3,73,courses,classes)==SUCCESS);
printFunc(73,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[74];
courses=new int[74];
//Line Number: 813
ASSERT_TEST(GetMostViewedClasses(DS3,74,courses,classes)==SUCCESS);
printFunc(74,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[75];
courses=new int[75];
//Line Number: 814
ASSERT_TEST(GetMostViewedClasses(DS3,75,courses,classes)==SUCCESS);
printFunc(75,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[76];
courses=new int[76];
//Line Number: 815
ASSERT_TEST(GetMostViewedClasses(DS3,76,courses,classes)==SUCCESS);
printFunc(76,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[77];
courses=new int[77];
//Line Number: 816
ASSERT_TEST(GetMostViewedClasses(DS3,77,courses,classes)==SUCCESS);
printFunc(77,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[78];
courses=new int[78];
//Line Number: 817
ASSERT_TEST(GetMostViewedClasses(DS3,78,courses,classes)==SUCCESS);
printFunc(78,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[79];
courses=new int[79];
//Line Number: 818
ASSERT_TEST(GetMostViewedClasses(DS3,79,courses,classes)==SUCCESS);
printFunc(79,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[80];
courses=new int[80];
//Line Number: 819
ASSERT_TEST(GetMostViewedClasses(DS3,80,courses,classes)==SUCCESS);
printFunc(80,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[81];
courses=new int[81];
//Line Number: 820
ASSERT_TEST(GetMostViewedClasses(DS3,81,courses,classes)==SUCCESS);
printFunc(81,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[82];
courses=new int[82];
//Line Number: 821
ASSERT_TEST(GetMostViewedClasses(DS3,82,courses,classes)==SUCCESS);
printFunc(82,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[83];
courses=new int[83];
//Line Number: 822
ASSERT_TEST(GetMostViewedClasses(DS3,83,courses,classes)==SUCCESS);
printFunc(83,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[84];
courses=new int[84];
//Line Number: 823
ASSERT_TEST(GetMostViewedClasses(DS3,84,courses,classes)==SUCCESS);
printFunc(84,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[85];
courses=new int[85];
//Line Number: 824
ASSERT_TEST(GetMostViewedClasses(DS3,85,courses,classes)==SUCCESS);
printFunc(85,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[86];
courses=new int[86];
//Line Number: 825
ASSERT_TEST(GetMostViewedClasses(DS3,86,courses,classes)==SUCCESS);
printFunc(86,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[87];
courses=new int[87];
//Line Number: 826
ASSERT_TEST(GetMostViewedClasses(DS3,87,courses,classes)==SUCCESS);
printFunc(87,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[88];
courses=new int[88];
//Line Number: 827
ASSERT_TEST(GetMostViewedClasses(DS3,88,courses,classes)==SUCCESS);
printFunc(88,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[89];
courses=new int[89];
//Line Number: 828
ASSERT_TEST(GetMostViewedClasses(DS3,89,courses,classes)==SUCCESS);
printFunc(89,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[90];
courses=new int[90];
//Line Number: 829
ASSERT_TEST(GetMostViewedClasses(DS3,90,courses,classes)==SUCCESS);
printFunc(90,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[91];
courses=new int[91];
//Line Number: 830
ASSERT_TEST(GetMostViewedClasses(DS3,91,courses,classes)==SUCCESS);
printFunc(91,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[92];
courses=new int[92];
//Line Number: 831
ASSERT_TEST(GetMostViewedClasses(DS3,92,courses,classes)==SUCCESS);
printFunc(92,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[93];
courses=new int[93];
//Line Number: 832
ASSERT_TEST(GetMostViewedClasses(DS3,93,courses,classes)==SUCCESS);
printFunc(93,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[94];
courses=new int[94];
//Line Number: 833
ASSERT_TEST(GetMostViewedClasses(DS3,94,courses,classes)==SUCCESS);
printFunc(94,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[95];
courses=new int[95];
//Line Number: 834
ASSERT_TEST(GetMostViewedClasses(DS3,95,courses,classes)==SUCCESS);
printFunc(95,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[96];
courses=new int[96];
//Line Number: 835
ASSERT_TEST(GetMostViewedClasses(DS3,96,courses,classes)==SUCCESS);
printFunc(96,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[97];
courses=new int[97];
//Line Number: 836
ASSERT_TEST(GetMostViewedClasses(DS3,97,courses,classes)==SUCCESS);
printFunc(97,courses,classes,myfile);
delete[] classes;
delete[] courses;
classes=new int[98];
courses=new int[98];
//Line Number: 837
ASSERT_TEST(GetMostViewedClasses(DS3,98,courses,classes)==SUCCESS);
printFunc(98,courses,classes,myfile);
delete[] classes;
delete[] courses;
//Line Number: 838
ASSERT_TEST(AddCourse(DS3,12,20)==SUCCESS);
//Line Number: 839
ASSERT_TEST(WatchClass(DS3,12,0,7)==SUCCESS);
//Line Number: 840
ASSERT_TEST(TimeViewed(DS3,12,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==7);
//Line Number: 841
ASSERT_TEST(WatchClass(DS3,12,0,7)==SUCCESS);
//Line Number: 842
ASSERT_TEST(TimeViewed(DS3,12,0,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==14);
//Line Number: 843
ASSERT_TEST(AddCourse(DS3,13,5)==FAILURE);
//Line Number: 844
ASSERT_TEST(WatchClass(DS3,13,1,18)==SUCCESS);
//Line Number: 845
ASSERT_TEST(TimeViewed(DS3,13,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
//Line Number: 846
ASSERT_TEST(WatchClass(DS3,13,1,18)==SUCCESS);
//Line Number: 847
ASSERT_TEST(TimeViewed(DS3,13,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==36);
//Line Number: 848
ASSERT_TEST(WatchClass(DS3,13,1,18)==SUCCESS);
//Line Number: 849
ASSERT_TEST(TimeViewed(DS3,13,1,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==54);
//Line Number: 850
ASSERT_TEST(WatchClass(DS3,13,3,18)==SUCCESS);
//Line Number: 851
ASSERT_TEST(TimeViewed(DS3,13,3,timeviewed)==SUCCESS);
ASSERT_TEST(*timeviewed==18);
delete timeviewed;
myfile.flush();
myfile.close();
}
